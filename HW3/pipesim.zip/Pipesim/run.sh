#!/bin/bash
rm -rf pipesim *.o output

mkdir output

make

./pipesim -i instruction.txt -f 0 >> output/instruction_1_no_forwarding.txt
./pipesim -i instruction.txt -f 1 >> output/instruction_1_forwarding_window_1.txt
./pipesim -i instruction.txt -f 2 >> output/instruction_1_forwarding_window_2.txt
./pipesim -i instruction2.txt -f 0 >> output/instruction_2_no_forwarding.txt
./pipesim -i instruction2.txt -f 1 >> output/instruction_2_forwarding_window_1.txt
./pipesim -i instruction2.txt -f 2 >> output/instruction_2_forwarding_window_2.txt
./pipesim -i instruction3.txt -f 0 >> output/instruction_3_no_forwarding.txt
./pipesim -i instruction3.txt -f 1 >> output/instruction_3_forwarding_window_1.txt
./pipesim -i instruction3.txt -f 2 >> output/instruction_3_forwarding_window_2.txt


